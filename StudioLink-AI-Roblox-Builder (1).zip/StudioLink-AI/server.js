const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const SETTINGS_PATH = path.join(ROOT, "settings.json");
const HOST = "127.0.0.1";
const PORT = Number(process.env.PORT || 3210);
const BRIDGE_TOKEN = "sl-local-bridge-2026-7c91d2";
const MAX_BODY = 160_000;

let queue = [];
let history = [];
let pluginLastSeen = null;
let settings = { apiKey: "", model: "gpt-4o-mini" };

try {
  if (fs.existsSync(SETTINGS_PATH)) {
    const saved = JSON.parse(fs.readFileSync(SETTINGS_PATH, "utf8"));
    settings = { ...settings, ...saved };
  }
} catch (e) {
  console.error("Не удалось прочитать settings.json:", e.message);
}

function saveSettings() {
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), { mode: 0o600 });
}
function send(res, status, data, type = "application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": type,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  res.end(type.startsWith("application/json") ? JSON.stringify(data) : data);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > MAX_BODY) {
        reject(new Error("Запрос слишком большой"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch { reject(new Error("Некорректный JSON")); }
    });
    req.on("error", reject);
  });
}
function pluginAuthorized(req) {
  return req.headers["x-studiolink-token"] === BRIDGE_TOKEN;
}
function cleanText(value, max = 12000) {
  return typeof value === "string" ? value.slice(0, max) : "";
}
function validatePlan(plan) {
  if (!plan || !Array.isArray(plan.actions)) throw new Error("ИИ вернул план без массива actions");
  if (plan.actions.length > 100) throw new Error("Слишком много действий (максимум 100 за один запрос)");
  const allowed = new Set([
    "createPart", "createFolder", "createModel", "createScript",
    "createScreenGui", "createTextLabel", "createTextButton",
    "createSpawnLocation", "setProperty", "deleteByName"
  ]);
  const safe = [];
  for (const raw of plan.actions) {
    if (!raw || !allowed.has(raw.type)) continue;
    const a = {
      id: crypto.randomUUID(),
      type: raw.type,
      name: cleanText(raw.name, 80) || "AIObject",
      parent: cleanText(raw.parent, 80) || "Workspace",
      className: cleanText(raw.className, 40),
      code: cleanText(raw.code, 24000),
      target: cleanText(raw.target, 80),
      property: cleanText(raw.property, 40),
      value: raw.value ?? null,
      size: raw.size ?? null,
      position: raw.position ?? null,
      color: cleanText(raw.color, 40),
      material: cleanText(raw.material, 40),
      anchored: raw.anchored !== false,
      text: cleanText(raw.text, 500),
      textSize: Number.isFinite(raw.textSize) ? Math.max(8, Math.min(72, raw.textSize)) : 20,
      backgroundColor: cleanText(raw.backgroundColor, 40),
      textColor: cleanText(raw.textColor, 40),
      explanation: cleanText(raw.explanation, 200)
    };
    if (a.type === "deleteByName" && (!a.target || ["Workspace", "game", "ServerScriptService"].includes(a.target))) {
      throw new Error("ИИ запросил небезопасное удаление объекта");
    }
    if (a.type === "setProperty" && !/^(Name|Anchored|CanCollide|Transparency|Reflectance|Material|Color|Size|Position|Text|TextSize|BackgroundColor3|TextColor3|Visible|Enabled)$/.test(a.property)) {
      throw new Error("ИИ запросил неподдерживаемое свойство: " + a.property);
    }
    safe.push(a);
  }
  return safe;
}
const SYSTEM_PROMPT = `Ты StudioLink AI — помощник по созданию Roblox-игр. Отвечай ТОЛЬКО валидным JSON-объектом вида {"message":"краткое описание на русском","actions":[...]}.
Преобразуй запрос в безопасный декларативный план для Roblox Studio. Не создавай сетевые запросы, загрузчики, require с asset ID, обфускацию, кражу данных, удаление чужого содержимого или обход ограничений.
Доступные действия:
- createPart: name,parent ("Workspace" или имя созданного Model/Folder), size [x,y,z], position [x,y,z], color (например "Bright blue", "Really red", "Institutional white", "Bright green", "New Yeller", "Hot pink", "Medium stone grey"), material ("Plastic","Neon","Wood","Concrete","Metal","Glass"), anchored boolean.
- createFolder: name,parent
- createModel: name,parent
- createScript: name,parent ("ServerScriptService" или "StarterPlayerScripts" или "StarterGui" или "Workspace"), className ("Script","LocalScript","ModuleScript"), code (Luau source). Скрипт только создаётся/сохраняется; не запускай и не утверждай, что он уже протестирован.
- createScreenGui: name,parent ("StarterGui")
- createTextLabel / createTextButton: name,parent ("ScreenGui" name), text, textSize, backgroundColor, textColor.
- createSpawnLocation: name,parent ("Workspace"), position [x,y,z]
- setProperty: target (объект по имени), property из Name, Anchored, CanCollide, Transparency, Reflectance, Material, Color, Size, Position, Text, TextSize, BackgroundColor3, TextColor3, Visible, Enabled; value.
- deleteByName: target (только конкретный объект, никогда не удаляй Workspace/сервисы).
Числа размеров/позиций должны быть в разумных пределах. Для карты создавай геометрию через Parts/Models, не обещай импорт сложных мешей или автоматическое sculpt terrain. Для GUI используй ScreenGui + TextLabel/TextButton; если нужно больше GUI-функций, добавляй скрипты, но не выполняй код на стороне сервера. Обычно выдавай конкретные действия и поясняй ограничения в message. До 100 actions. Все ключи каждого действия можно указывать по необходимости.`;
function extractOutputText(response) {
  if (typeof response.output_text === "string") return response.output_text;
  for (const item of response.output || []) {
    if (item.type === "message") {
      for (const c of item.content || []) if (c.type === "output_text") return c.text;
    }
  }
  return "";
}
async function callOpenAI(prompt) {
  if (!settings.apiKey) throw new Error("Сначала добавь OpenAI API key в настройках сайта.");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${settings.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: settings.model || "gpt-4o-mini",
      input: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt }
      ],
      text: { format: { type: "json_object" } },
      max_output_tokens: 12000
    })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = payload.error?.message || `OpenAI API вернул HTTP ${response.status}`;
    throw new Error(detail);
  }
  const outputText = extractOutputText(payload);
  if (!outputText) throw new Error("ИИ вернул пустой ответ. Попробуй ещё раз.");
  let plan;
  try { plan = JSON.parse(outputText); }
  catch { throw new Error("ИИ вернул некорректный JSON. Попробуй уточнить промпт."); }
  const actions = validatePlan(plan);
  const jobId = crypto.randomUUID();
  const job = {
    id: jobId,
    createdAt: new Date().toISOString(),
    message: cleanText(plan.message, 2000) || "План подготовлен.",
    prompt: cleanText(prompt, 5000),
    total: actions.length,
    remaining: actions.length,
    status: actions.length ? "queued" : "done"
  };
  history.unshift(job);
  history = history.slice(0, 30);
  for (const action of actions) queue.push({ ...action, jobId });
  return { job, actionsCount: actions.length };
}
async function handle(req, res) {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  if (req.method === "GET" && url.pathname === "/api/status") {
    return send(res, 200, {
      ok: true, queued: queue.length, pluginConnected: pluginLastSeen !== null && Date.now() - pluginLastSeen < 15000,
      pluginLastSeen: pluginLastSeen ? new Date(pluginLastSeen).toISOString() : null,
      configured: Boolean(settings.apiKey), model: settings.model
    });
  }
  if (req.method === "GET" && url.pathname === "/api/settings") {
    return send(res, 200, { configured: Boolean(settings.apiKey), maskedKey: settings.apiKey ? "••••••••" + settings.apiKey.slice(-4) : "", model: settings.model });
  }
  if (req.method === "POST" && url.pathname === "/api/settings") {
    const body = await readBody(req);
    const key = cleanText(body.apiKey, 300);
    if (key) {
      if (!key.startsWith("sk-")) return send(res, 400, { error: "Ключ обычно начинается с sk-. Проверь, что скопирован полный API key." });
      settings.apiKey = key;
    }
    const model = cleanText(body.model, 80);
    if (model) settings.model = model;
    saveSettings();
    return send(res, 200, { ok: true, configured: Boolean(settings.apiKey), model: settings.model });
  }
  if (req.method === "POST" && url.pathname === "/api/prompt") {
    const body = await readBody(req);
    const prompt = cleanText(body.prompt, 5000).trim();
    if (!prompt) return send(res, 400, { error: "Напиши, что нужно создать." });
    try {
      const result = await callOpenAI(prompt);
      return send(res, 200, { ok: true, ...result });
    } catch (e) {
      return send(res, 502, { error: e.message || "Ошибка генерации" });
    }
  }
  if (url.pathname.startsWith("/api/plugin/")) {
    if (!pluginAuthorized(req)) return send(res, 401, { error: "Неверный токен плагина" });
    if (req.method === "GET" && url.pathname === "/api/plugin/next") {
      pluginLastSeen = Date.now();
      const action = queue.shift() || null;
      if (action) {
        const job = history.find(h => h.id === action.jobId);
        if (job) job.remaining = Math.max(0, job.remaining - 1);
      }
      return send(res, 200, { action, queued: queue.length });
    }
    if (req.method === "POST" && url.pathname === "/api/plugin/result") {
      const body = await readBody(req);
      pluginLastSeen = Date.now();
      const entry = { at: new Date().toISOString(), ok: Boolean(body.ok), name: cleanText(body.name, 100), error: cleanText(body.error, 500) };
      // Store bounded event feed for UI polling.
      events.unshift(entry); events = events.slice(0, 60);
      return send(res, 200, { ok: true });
    }
  }
  if (req.method === "GET" && url.pathname === "/api/events") return send(res, 200, { events });
  if (req.method === "GET") {
    const relative = url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname.slice(1));
    const file = path.resolve(PUBLIC, relative);
    if (!file.startsWith(PUBLIC + path.sep) && file !== path.join(PUBLIC, "index.html")) return send(res, 403, { error: "Forbidden" });
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return send(res, 404, { error: "Not found" });
    const ext = path.extname(file).toLowerCase();
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".svg": "image/svg+xml" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    return fs.createReadStream(file).pipe(res);
  }
  return send(res, 404, { error: "Not found" });
}
let events = [];
const server = http.createServer((req, res) => {
  handle(req, res).catch(err => {
    if (!res.headersSent) send(res, 500, { error: err.message || "Внутренняя ошибка сервера" });
    else res.destroy();
    console.error(err);
  });
});
server.listen(PORT, HOST, () => {
  console.log(`\nStudioLink AI запущен: http://${HOST}:${PORT}`);
  console.log("Это локальный сервер. Оставь это окно открытым.");
  console.log("API key хранится в settings.json на этом компьютере.\n");
});
