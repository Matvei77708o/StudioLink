# StudioLink AI — Roblox Studio AI builder

StudioLink AI is a local Windows app that sends a prompt to the OpenAI API, converts the answer into a restricted list of Roblox Studio actions, and lets a Studio plugin apply those actions in the open place.

## What it can do
- Build simple maps from anchored Parts, Models and Folders.
- Create SpawnLocations.
- Create ScreenGui, TextLabels and TextButtons.
- Generate and insert Script, LocalScript and ModuleScript source.
- Change selected supported properties and delete a specifically named object.
- Show plugin connection status and plugin-reported action results.

This is a starter project, not a magical one-click full game generator. Complex terrain sculpting, mesh creation, testing/fixing generated gameplay, and advanced UI layouts may need follow-up prompts. Generated scripts are inserted but are not run automatically in Edit mode. Inspect scripts before playtesting.

## Requirements
- Windows 10/11
- Node.js 18 or newer (Node 20 LTS recommended)
- An OpenAI API key with API billing/access enabled
- Roblox Studio

## 1. Start the local website
1. Extract this folder to a normal writable location, e.g. `C:\StudioLink-AI`.
2. Double-click `start.bat`.
3. Keep the terminal window open.
4. Open `http://127.0.0.1:3210/` in a browser.

The server binds only to `127.0.0.1` (your own computer), not the public network.

## 2. Configure OpenAI
1. In the website, click **Настройки API**.
2. Paste your OpenAI API key and choose a model.
3. Click **Сохранить настройки**.
4. The key is saved in `settings.json` beside `server.js`. Do not upload/share that file or the whole configured folder. If you accidentally expose the key, revoke it from your OpenAI account and create a new one.

API usage may cost money separately from a ChatGPT subscription. Model availability and pricing depend on your OpenAI account.

## 3. Install the Roblox Studio plugin
1. In Studio, open **Plugins → Plugins Folder** (or use the local plugins folder for your OS).
2. Copy `plugin\StudioLinkAI.plugin.lua` into the plugins folder.
3. If Studio requires a plugin package, create a local plugin in Studio and paste the file's source into its Script, then save it as `StudioLink AI`.
4. Restart Roblox Studio if needed.
5. Make sure the StudioLink website server is running.
6. In Studio, open the **Plugins** tab and click **StudioLink AI**. The plugin's dock panel should show connection status.
7. The first connection to localhost may require accepting Roblox Studio's plugin network permission prompt.

The plugin talks to `http://127.0.0.1:3210` using the shared local bridge token embedded in `server.js` and `plugin\StudioLinkAI.plugin.lua`. Do not expose this server to the internet.

## 4. Build something
Try:
> Создай obby-карту из 10 платформ, красных опасных блоков и зелёного финиша. Все объекты должны быть Anchored.

Then:
1. Click **Создать в Studio**.
2. Keep Studio open with the plugin enabled.
3. Watch the plugin panel and the website activity feed.
4. Save your place after reviewing the generated objects and scripts.

## Troubleshooting
- **Website doesn't open:** run `node -v` in Command Prompt; install Node.js 18+ if missing. Browse to `http://127.0.0.1:3210/`, not `/api/status`.
- **The browser shows `{"type":"Buffer","data":[...]}`:** make sure you are running this version's `server.js`, not the older folder.
- **API key error:** check that the key is complete, valid, and has API access/billing enabled.
- **Plugin cannot connect:** leave `start.bat` running, restart the plugin, check the exact URL/port, and accept the Studio network permission prompt if shown.
- **No actions appear:** check the plugin panel and the website activity feed. A prompt may produce a plan with zero actions if it only asks a question.
- **Scripts don't run while editing:** normal behavior; playtest after inspecting the generated source.

## Security notes
- The API key stays on the local server and is never returned to the page after saving.
- The app has no user login; keep it bound to localhost and do not port-forward it.
- AI-generated code can be wrong or harmful. This starter app limits the action types, but generated script source is still code. Review it before playtesting, and keep a backup of important projects.
