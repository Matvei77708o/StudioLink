const $ = id => document.getElementById(id);
const dialog = $("settingsDialog");
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}
function showResult(text, bad = false) {
  const el = $("result");
  el.textContent = text;
  el.classList.remove("hidden");
  el.style.borderColor = bad ? "#663346" : "#3a355c";
  el.style.color = bad ? "#ff9caf" : "#d8d0ff";
}
$("openSettings").addEventListener("click", async () => {
  try {
    const data = await api("/api/settings");
    $("keyStatus").textContent = data.configured ? `Ключ сохранён (${data.maskedKey})` : "Ключ не настроен";
    $("model").value = data.model || "gpt-4o-mini";
    $("apiKey").value = "";
    $("settingsMessage").textContent = "";
  } catch (e) { $("settingsMessage").textContent = e.message; }
  dialog.showModal();
});
$("closeSettings").addEventListener("click", () => dialog.close());
$("settingsForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("settingsMessage").textContent = "Сохраняю…";
  try {
    const result = await api("/api/settings", { method: "POST", body: JSON.stringify({ apiKey: $("apiKey").value.trim(), model: $("model").value }) });
    $("keyStatus").textContent = result.configured ? "API key настроен" : "Ключ не настроен";
    $("apiKey").value = "";
    $("settingsMessage").textContent = "Настройки сохранены.";
    await refreshStatus();
  } catch (err) { $("settingsMessage").textContent = err.message; }
});
$("testKey").addEventListener("click", async () => {
  try { const d = await api("/api/settings"); $("settingsMessage").textContent = d.configured ? `Ключ сохранён. Модель: ${d.model}` : "Сначала введи API key."; }
  catch (e) { $("settingsMessage").textContent = e.message; }
});
document.querySelectorAll(".example").forEach(btn => btn.addEventListener("click", () => { $("prompt").value = btn.dataset.prompt; $("prompt").focus(); }));
$("promptForm").addEventListener("submit", async e => {
  e.preventDefault();
  const prompt = $("prompt").value.trim();
  if (!prompt) return;
  $("sendBtn").disabled = true;
  $("sendBtn").textContent = "✦ ИИ генерирует…";
  showResult("Отправляю запрос модели. Это может занять несколько секунд…");
  try {
    const data = await api("/api/prompt", { method: "POST", body: JSON.stringify({ prompt }) });
    showResult(`${data.job.message}\n\nОпераций создано: ${data.actionsCount}.\nПлагин автоматически заберёт очередь, когда подключится к Studio.`);
    await refreshAll();
  } catch (err) { showResult(err.message, true); }
  finally { $("sendBtn").disabled = false; $("sendBtn").innerHTML = '✦ Создать в Studio <span>↗</span>'; }
});
$("refresh").addEventListener("click", refreshAll);
async function refreshStatus() {
  try {
    const d = await api("/api/status");
    $("queueBadge").textContent = d.queued;
    $("queueCount").textContent = `${d.queued} действий`;
    $("apiState").textContent = d.configured ? "Настроен" : "Не настроен";
    $("modelName").textContent = d.model || "—";
    $("studioState").textContent = d.pluginConnected ? "Подключён" : "Ожидание плагина";
    $("pluginState").textContent = d.pluginConnected ? "Плагин подключён" : "Плагин не найден";
    $("serverState").textContent = d.pluginConnected ? "Roblox Studio на связи" : "Запусти плагин в Studio";
    $("dot").classList.toggle("online", d.pluginConnected);
  } catch { $("serverState").textContent = "Нет соединения с сервером"; }
}
async function refreshEvents() {
  try {
    const d = await api("/api/events");
    $("events").innerHTML = "";
    if (!d.events.length) { $("events").innerHTML = '<div class="empty">Пока нет событий от плагина.</div>'; return; }
    for (const event of d.events.slice(0, 15)) {
      const node = document.createElement("div"); node.className = "event";
      const icon = document.createElement("div"); icon.className = "event-icon" + (event.ok ? "" : " bad"); icon.textContent = event.ok ? "✓" : "!";
      const content = document.createElement("div");
      const title = document.createElement("b"); title.textContent = event.ok ? `Создано/изменено: ${event.name || "объект"}` : `Ошибка: ${event.name || "действие"}`;
      const detail = document.createElement("p"); detail.textContent = event.error || new Date(event.at).toLocaleTimeString();
      content.append(title, detail); node.append(icon, content); $("events").append(node);
    }
  } catch {}
}
async function refreshAll() { await Promise.all([refreshStatus(), refreshEvents()]); }
refreshAll();
setInterval(refreshAll, 2500);
