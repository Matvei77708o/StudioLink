-- StudioLink AI plugin. Install this file as a local Studio plugin.
local HttpService = game:GetService("HttpService")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local BASE = "http://127.0.0.1:3210"
local TOKEN = "sl-local-bridge-2026-7c91d2"
local POLL_SECONDS = 1.2
local running = true

local toolbar = plugin:CreateToolbar("StudioLink AI")
local toggle = toolbar:CreateButton("StudioLink AI", "Toggle StudioLink AI connection", "rbxassetid://4458901886")
toggle.ClickableWhenViewportHidden = true

local widgetInfo = DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Right, true, false, 320, 180, 260, 120)
local widget = plugin:CreateDockWidgetPluginGui("StudioLinkAIWidget", widgetInfo)
widget.Title = "StudioLink AI"
local frame = Instance.new("Frame")
frame.Size = UDim2.fromScale(1, 1)
frame.BackgroundColor3 = Color3.fromRGB(20, 23, 34)
frame.Parent = widget
local status = Instance.new("TextLabel")
status.Size = UDim2.new(1, -20, 0, 60)
status.Position = UDim2.fromOffset(10, 10)
status.BackgroundTransparency = 1
status.TextColor3 = Color3.fromRGB(225, 230, 245)
status.TextWrapped = true
status.TextSize = 14
status.Font = Enum.Font.Gotham
status.Text = "StudioLink AI: подключение…"
status.Parent = frame
local note = Instance.new("TextLabel")
note.Size = UDim2.new(1, -20, 0, 60)
note.Position = UDim2.fromOffset(10, 75)
note.BackgroundTransparency = 1
note.TextColor3 = Color3.fromRGB(150, 160, 185)
note.TextWrapped = true
note.TextSize = 12
note.Font = Enum.Font.Gotham
note.Text = "Оставь плагин включённым. Команды из сайта применяются к открытому проекту."
note.Parent = frame

local colors = {
    ["Bright blue"] = BrickColor.new("Bright blue"), ["Really red"] = BrickColor.new("Really red"),
    ["Institutional white"] = BrickColor.new("Institutional white"), ["Bright green"] = BrickColor.new("Bright green"),
    ["New Yeller"] = BrickColor.new("New Yeller"), ["Hot pink"] = BrickColor.new("Hot pink"),
    ["Medium stone grey"] = BrickColor.new("Medium stone grey"), ["Really black"] = BrickColor.new("Really black"),
    ["Bright orange"] = BrickColor.new("Bright orange"), ["Royal purple"] = BrickColor.new("Royal purple"),
}
local materials = {
    Plastic = Enum.Material.Plastic, Neon = Enum.Material.Neon, Wood = Enum.Material.Wood,
    Concrete = Enum.Material.Concrete, Metal = Enum.Material.Metal, Glass = Enum.Material.Glass,
}
local function findParent(name)
    if not name or name == "" or name == "Workspace" then return workspace end
    local services = {
        ServerScriptService = game:GetService("ServerScriptService"),
        StarterPlayerScripts = game:GetService("StarterPlayer").StarterPlayerScripts,
        StarterGui = game:GetService("StarterGui"),
        ReplicatedStorage = game:GetService("ReplicatedStorage"),
        Workspace = workspace,
    }
    if services[name] then return services[name] end
    return game:FindFirstChild(name, true) or workspace
end
local function vector3(value, fallback)
    if type(value) == "table" and #value >= 3 then
        local x, y, z = tonumber(value[1]) or 0, tonumber(value[2]) or 0, tonumber(value[3]) or 0
        return Vector3.new(math.clamp(x, -2048, 2048), math.clamp(y, -2048, 2048), math.clamp(z, -2048, 2048))
    end
    return fallback
end
local function setColor(part, name)
    if colors[name] then part.BrickColor = colors[name] end
end
local function report(action, ok, err)
    pcall(function()
        HttpService:RequestAsync({
            Url = BASE .. "/api/plugin/result", Method = "POST",
            Headers = { ["Content-Type"] = "application/json", ["x-studiolink-token"] = TOKEN },
            Body = HttpService:JSONEncode({ ok = ok, name = action.name or action.type or "action", error = err or "" })
        })
    end)
end
local function apply(action)
    local kind = action.type
    local parent = findParent(action.parent)
    local obj
    if kind == "createPart" then
        obj = Instance.new("Part")
        obj.Name = action.name or "AI_Part"
        obj.Size = vector3(action.size, Vector3.new(4, 1, 4))
        obj.Position = vector3(action.position, Vector3.new(0, 5, 0))
        obj.Anchored = action.anchored ~= false
        obj.TopSurface = Enum.SurfaceType.Smooth
        obj.BottomSurface = Enum.SurfaceType.Smooth
        setColor(obj, action.color)
        if materials[action.material] then obj.Material = materials[action.material] end
        obj.Parent = parent
    elseif kind == "createFolder" then
        obj = Instance.new("Folder"); obj.Name = action.name or "AIFolder"; obj.Parent = parent
    elseif kind == "createModel" then
        obj = Instance.new("Model"); obj.Name = action.name or "AIModel"; obj.Parent = parent
    elseif kind == "createScript" then
        local className = action.className
        if className ~= "Script" and className ~= "LocalScript" and className ~= "ModuleScript" then className = "Script" end
        obj = Instance.new(className); obj.Name = action.name or "AIScript"; obj.Source = action.code or "-- Generated by StudioLink AI"; obj.Parent = parent
    elseif kind == "createScreenGui" then
        obj = Instance.new("ScreenGui"); obj.Name = action.name or "AIScreenGui"; obj.ResetOnSpawn = false; obj.Parent = parent
    elseif kind == "createTextLabel" or kind == "createTextButton" then
        obj = Instance.new(kind == "createTextLabel" and "TextLabel" or "TextButton")
        obj.Name = action.name or (kind == "createTextLabel" and "AILabel" or "AIButton")
        obj.Text = action.text or obj.Name
        obj.TextSize = math.clamp(tonumber(action.textSize) or 20, 8, 72)
        obj.Font = Enum.Font.GothamBold
        obj.TextWrapped = true
        obj.Size = UDim2.new(0, 220, 0, 48)
        obj.Position = UDim2.new(0.5, -110, 0.15, 0)
        obj.AnchorPoint = Vector2.new(0, 0)
        obj.BackgroundColor3 = colors[action.backgroundColor] and colors[action.backgroundColor].Color or Color3.fromRGB(32, 37, 54)
        obj.TextColor3 = colors[action.textColor] and colors[action.textColor].Color or Color3.fromRGB(255, 255, 255)
        obj.BorderSizePixel = 0
        obj.Parent = parent
    elseif kind == "createSpawnLocation" then
        obj = Instance.new("SpawnLocation"); obj.Name = action.name or "AISpawn"
        obj.Size = Vector3.new(6, 1, 6); obj.Position = vector3(action.position, Vector3.new(0, 2, 0))
        obj.Anchored = true; obj.Neutral = true; obj.Parent = parent
    elseif kind == "setProperty" then
        obj = game:FindFirstChild(action.target or "", true)
        if not obj then error("Объект не найден: " .. tostring(action.target)) end
        local property = action.property
        local value = action.value
        if property == "Name" then obj.Name = tostring(value)
        elseif property == "Anchored" and obj:IsA("BasePart") then obj.Anchored = value == true
        elseif property == "CanCollide" and obj:IsA("BasePart") then obj.CanCollide = value == true
        elseif property == "Transparency" and obj:IsA("BasePart") then obj.Transparency = math.clamp(tonumber(value) or 0, 0, 1)
        elseif property == "Reflectance" and obj:IsA("BasePart") then obj.Reflectance = math.clamp(tonumber(value) or 0, 0, 1)
        elseif property == "Material" and obj:IsA("BasePart") and materials[tostring(value)] then obj.Material = materials[tostring(value)]
        elseif property == "Color" and obj:IsA("BasePart") then setColor(obj, tostring(value))
        elseif property == "Size" and obj:IsA("BasePart") then obj.Size = vector3(value, obj.Size)
        elseif property == "Position" and obj:IsA("BasePart") then obj.Position = vector3(value, obj.Position)
        elseif property == "Text" and (obj:IsA("TextLabel") or obj:IsA("TextButton") or obj:IsA("TextBox")) then obj.Text = tostring(value)
        elseif property == "TextSize" and (obj:IsA("TextLabel") or obj:IsA("TextButton") or obj:IsA("TextBox")) then obj.TextSize = math.clamp(tonumber(value) or 20, 8, 72)
        elseif property == "Visible" and obj:IsA("GuiObject") then obj.Visible = value == true
        elseif property == "Enabled" and (obj:IsA("ScreenGui") or obj:IsA("BillboardGui")) then obj.Enabled = value == true
        else error("Свойство не поддерживается для этого класса: " .. tostring(property)) end
    elseif kind == "deleteByName" then
        local target = game:FindFirstChild(action.target or "", true)
        if not target or target == workspace or target == game then error("Объект для удаления не найден или запрещён") end
        target:Destroy(); obj = target
    else
        error("Неизвестный тип действия: " .. tostring(kind))
    end
    return obj and obj.Name or action.name or kind
end
local busy = false
local function poll()
    if busy then return end
    busy = true
    local ok, response = pcall(function()
        return HttpService:RequestAsync({
            Url = BASE .. "/api/plugin/next", Method = "GET",
            Headers = { ["x-studiolink-token"] = TOKEN }
        })
    end)
    if not ok or not response or not response.Success then
        status.Text = "Нет связи с сервером StudioLink. Проверь, что start.bat запущен."
        busy = false
        return
    end
    local decodedOk, data = pcall(function() return HttpService:JSONDecode(response.Body) end)
    if decodedOk and data then
        status.Text = "Подключён к StudioLink AI\nВ очереди: " .. tostring(data.queued or 0)
        if data.action then
            local action = data.action
            local success, result = pcall(function()
                ChangeHistoryService:SetWaypoint("StudioLink AI: before")
                local name = apply(action)
                ChangeHistoryService:SetWaypoint("StudioLink AI: " .. tostring(name))
                return name
            end)
            report(action, success, success and "" or tostring(result))
            if success then
                note.Text = "Готово: " .. tostring(result) .. "\nДействие применено в текущем проекте."
            else
                note.Text = "Ошибка действия: " .. tostring(result)
            end
        end
    end
    busy = false
end
toggle.Click:Connect(function() widget.Enabled = not widget.Enabled end)
widget:BindToClose(function() widget.Enabled = false end)
task.spawn(function()
    while running do
        poll()
        task.wait(POLL_SECONDS)
    end
end)
plugin.Unloading:Connect(function() running = false end)
